#include <iostream>
#include <string.h>
#include <stdio.h>
using namespace std;

int main()
{
    char a[50];
    fstream fin("text.in");
    f.get(a,50);
    fstream fout("text.out");
    for(int i=0;i<strlen(a);i++)
    {
        if(isdigit(a[i]))
        {
            g<<a[i];
            if(isalpha(a[i+1]))
                g<<endl;
        }
    }
    f.close();
    g.close();
}
